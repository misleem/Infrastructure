package ps.police.core.person

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:12 AM
 * @param
 *
 * This class represents the security reports about  a person
 *
 * orderId: the report number identifier ( in other words, the order identifier which added the security report to the person history)
 * orderDate: when the order is issued
 * orderFrom: the order issuing party
 * orderSubject: the order subject
 * procedure: the procedures of the order (what should happen?)
 * note: general description about the order
 * person: a specific person to whom the report is added
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
public class SecurityReport {

    int orderId
    Date orderDate
    String orderFrom
    String orderSubject
    String procedure
    String note

    static belongsTo = [person: Person]
    static constraints = {

        orderFrom(nullable: false, blank: false, size: 1..100)
        orderSubject(nullable: false, blank: false, size: 1..100)
        orderDate(nullable: false)
        note(nullable: true, blank: true, size: 1..1000)
        procedure(nullable: true, blank: true, size: 1..100)
		orderId(unique:true)
    }
    static mapping = { note type: "text" }
}
