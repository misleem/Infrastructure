package ps.police.core.person

import ps.police.core.common.LanguageCodeLookup
import ps.police.core.person.lookup.*
/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents a person identification marks.In other words, marks that help in recognizing a person
 * ageFrom: when the mark appeared in the person   [NOT NULL]
 * ageTo: when the mark disappeared in the person   [NOT NULL]
 *  specialSkills: the person special skills  [NOT NULL]
 *  personVoice: the person voice tone
 *  informationMarker: more information and description about the person
 *  shoeSize: the person shoe size
 *  shirtSize: the person shirt size
 *  pantsSize: the person pants size
 *  jacketSize: the person jacket size
 *  height: how tall the person is
 * weight: the person weight
 *  hairColor: the person hair color
 *  hairFeature: the person hair feature like "Rough, Curly ... "
 * eyeColor: the person eye  color
 * skinColor: the person skin color
 * psychopathicLevel: the person psychopathic Level  like "Normal, dangerous .. "
 * preferredLanguage: the best language spoken by the person    [NOT NULL]
 *
 *
 *
 *
 *
 *
 *
 */


class IdentificationMark implements Serializable {

    private static final long serialVersionUID = 1L
    Date dateCreated
    Date lastUpdated

    Integer ageFrom // 10 to 70 years old
    Integer ageTo // 10 to 70  years old

    String specialSkills
    String personVoice
    String personAccent
    String informationMarker

    int shoeSize  // in europe scale: 30 to 55
    String shirtSize
    int pantsSize
    int jacketSize
    double height  // in meters 1.0 to 3.0 meters
    int weight    // in kilos

    static belongsTo = [person: Person,
            hairColor: HairColor,
            hairFeature: HairFeature,
            eyeColor: EyeColor,
            skinColor: SkinColor,
            psychopathicLevel: PsychopathicLevel,
            preferredLanguage: LanguageCodeLookup]

    static constraints = {
        person(nullable: false)
        ageFrom(nullable: false, range: 10..70);
//        validator: {val, obj -> // @Constraint : This.ageFrom should not interfere with previous periods.
//            if (IdentificationMark.findAllByPersonAndAgeToGreaterThan(obj.person, val).size() > 0)
//                return false;
//            return true;
//        })

        ageTo(nullable: false, range: 10..70,
                validator: {val, obj ->
                    if (obj.ageFrom == null || val == null)
                        return true;
                    if (val.compareTo(obj.ageFrom?.intValue()) < 0) // @Constraint : this.ageTo < this.ageFrom ?
                        return false;
                    return true;
                })
        shoeSize(nullable: true, range: 30..55)

        jacketSize(nullable: true, range: 30..58)
        pantsSize(nullable: true, range: 17..72)
        shirtSize(nullable: true)


        height(nullable: true, range: 1D..3D) // height in meters : 1.0m to 3.0m
        weight(nullable: true, range: 20..150) // weight in kilos : 20kg to 150kg

        personVoice(nullable: true, blank: false, size: 5..30)
        specialSkills(nullable: true, blank: false, size: 5..100)
        personAccent(nullable: true, blank: false, size: 5..100)
        informationMarker(nullable: true, blank: false, size: 5..100)


        preferredLanguage(nullable: false)
        hairColor(nullable: true)
        hairFeature(nullable: true)
        eyeColor(nullable: true)
        skinColor(nullable: true)
        personVoice(nullable: true)
        psychopathicLevel(nullable: true)


    }

    static mapping = {
        preferredLanguage lazy: false
    }
}
