package ps.police.core.person

import ps.police.core.location.Country
import ps.police.core.person.lookup.*


/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:05 AM
 * @param: This class represents a person demographical data
 *
 *  numberOfChildren: the person number of children
 *  motherOccupation: the person mother occupation
 *  fatherOccupation: the person father occupation
 *  raceCode: unused
 *  ethnicity: the person ethnicity like "Armenians,Samaritan .. "
 *  gender : the person gender type [Male or Female]
 *  maritalStatus: the person marital status [single, married...]
 *  religion: the person religion
 *  citizenship: the person citizenship like Palestinian
 *  residency: the country where the person lives
 *  bloodType: the person blood type [O+, AB+ ...]
 *  liveStatus: the person live status like [alive, dead..]
 *
 *
 *
 *
 *
 *
 *
 *
 */

class DemographicDescriptor implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Long numberOfChildren
    String motherOccupation
    String fatherOccupation

    static belongsTo = [ raceCode: RaceCode,
            ethnicity: Ethnicity,
            gender: GenderType,
            maritalStatus: MaritalStatus,
            religion: Religion,
            citizenship: Country,
            residency: Country, bloodType: BloodType, liveStatus: LiveStatus]

    static constraints = {
        motherOccupation(nullable: true)
        fatherOccupation(nullable: true)
        numberOfChildren(nullable: true)
        raceCode(nullable: true)
        ethnicity(nullable: true)
        religion(nullable: false)
        bloodType(nullable: true)
        gender(nullable: false)
        maritalStatus(nullable: true)
        citizenship(nullable: true)
        residency(nullable: true)
        liveStatus(nullable: true)
    }

}
