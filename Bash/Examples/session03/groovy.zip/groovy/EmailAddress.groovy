package ps.police.core.person


/*
*
*
* Obsolete class
*
*
* */

class EmailAddress implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated

    String email

    boolean vaildEmail

    static belongsTo = [contactDetails: ContactDetails]

    static constraints = {
        email(nullable: true, blank: true, size: 1..64)
        vaildEmail(nullable: true)
    }
}
