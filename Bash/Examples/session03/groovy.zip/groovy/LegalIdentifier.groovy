package ps.police.core.person



import ps.police.core.person.lookup.*;

import ps.police.core.location.*;

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents the person legal identifiers. Legal identifiers are legal documents related to a person
 *
 * idName: the name of the document, for example Italian ID document (the title of the document)
 * idValue: the value of the document, for example, the ID number, [NOT NULL]
 * idSource: the issuing party, for example, the Ministry of Interior Affairs
 * issuingRegion: the region where the issuing party is located
 * jurisdiction: why the issuing party issued the document for the person
 * validFrom: when the document is considered valid
 * validTo: when is the document is considered invalid
 * person: the person who owns the document [NOT NULL]
 * documentType: the document type, for example, Passport, ID
 * country: the issuing country
 *
 *
 *
 *
 *
 *
 *
 *
 */

class LegalIdentifier implements Serializable {

    private static final long serialVersionUID = 1L

    String idName
    String idValue
    String idSource
    String issuingRegion
    String jurisdiction
    Date validFrom
    Date validTo
    Person person
    DocumentType documentType
    Country country
    Date dateCreated
    Date lastUpdated
    static belongsTo = [person: Person]

    static constraints = {
        idName(nullable: true, blank: true, size: 1..100)
        idValue(nullable: false, blank: false, size: 1..20)
        idSource(nullable: true, blank: true, size: 1..100)
        issuingRegion(nullable: true, blank: true, size: 1..100)
        jurisdiction(nullable: true, blank: true, size: 1..100)
        country(nullable: true)
        documentType(nullable: true)
        person(nullable: false)
        validTo(nullable: true)
        validFrom(nullable: true)
    }
}
