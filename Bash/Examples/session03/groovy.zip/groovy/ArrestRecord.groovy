
package ps.police.core.person




/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:08 AM
 * @param: This class represents a person arrest records. This includes arrests in the Israeli jails and Palestinain jails as well.
 *
 * arrestDate: when the person is arrested
 * jailName: the jail name where the person is arrested
 * accusation: why the person is arrested
 * releaseDate: when the person is released
 * arrestReason: More details about why the person is arrested
 * lawyerName: the name of the person lawyer while he/she was arrested
 *
 *
 */
public class ArrestRecord  implements Serializable {
    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated

    Date arrestDate;
    String jailName;
    String accusation;
    Date releaseDate;
    int arrestperiod;
   // String Nameofthelawyer;
    String arrestReason;
     String lawyerName;

    static belongsTo = [person:Person]

    static constraints = {
        arrestDate(nullable:false)
        releaseDate(nullable: true, validator: {val, obj ->
            return val == null || val.after(obj.arrestDate)
        })
        jailName    (nullable: false, blank: false, size: 3..100)
        accusation(nullable: false, blank: false, size: 2..50)
        arrestReason(nullable: true, blank: false, size: 10..200)
        lawyerName(nullable: true, blank: false, size: 3..30)
    }
}