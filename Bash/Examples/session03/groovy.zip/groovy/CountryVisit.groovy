package ps.police.core.person

import ps.police.core.location.*;

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:05 AM
 * @param: This class represents the countries that a person  visited.
 *  visitDate:the date when the person visited the country
 *  returnDate: the date when the visit ended
 *  reasonForVisit: why the person visited the country
 *  countryName: the visited country by the person
 *  person: the person who visited the country
 *
 *
 *
 *
 *
 *
 */
public class CountryVisit implements Serializable {

    static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Date visitDate;
    Date returnDate;
    String reasonForVisit;
    static belongsTo = [countryName: Country, person: Person]
    static constraints = {
		returnDate(nullable:true, blank:true)
		visitDate (nullable:false,blank:false)
		reasonForVisit(nullable:false,blank:false)
		
    }

    static mapping = { reasonForVisit type: 'text' }
}