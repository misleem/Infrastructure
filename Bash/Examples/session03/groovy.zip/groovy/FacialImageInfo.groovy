package ps.police.core.person




/*
*
* Obsolete Class
*
*
*
* */

class FacialImageInfo implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    FacialImageHeader facialImageHeader
    FacialImageHeaderRecord facialImageHeaderRecord

    static belongsTo = [person: Person]

    static constraints = {
        facialImageHeader(nullable: true)
        facialImageHeaderRecord(nullable: true)
    }
}
