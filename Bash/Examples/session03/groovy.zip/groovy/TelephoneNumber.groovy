package ps.police.core.person

/*
*
*
*
* Obsolete Class
*
*
* */

class TelephoneNumber implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated

    String telephoneNumber
    String simType
    boolean vaildTelephoneNumber

    static belongsTo = [contactDetails: ContactDetails]

    static constraints = {

        telephoneNumber(nullable: true, blank: true, size: 1..20)
        simType(nullable: true, blank: true, size: 1..64)
        vaildTelephoneNumber(nullable: true)
    }
}
