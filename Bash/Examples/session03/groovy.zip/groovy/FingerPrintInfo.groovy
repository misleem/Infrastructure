package ps.police.core.person


/*
*
* Obsolete Class
*
*
*
* */

class FingerPrintInfo implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated

    FingerPrintHeader fingerPrintHeader
    FingerPrintHeaderRecord fingerPrintHeaderRecord

    static belongsTo = [person: Person]

    static constraints = {
    }
}
