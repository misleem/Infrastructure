package ps.police.core.person

import java.io.Serializable
import java.util.Date
import ps.police.core.person.Person
import ps.police.core.person.lookup.DeathVerification
import ps.police.core.location.Location


/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents the way to declare that a person is dead
 *
 *  person: the dead person                                              [NOT Null]
 *  deathVerification: the death verification way like death certificate [NOT Null]
 *  personDeath: the date when the person died [NOT Null]
 *
 *
 *
 *
 *
 *
 *
 */

class PersonDeath implements Serializable {
    private static final long serialVersionUID = 1L
    Date dateCreated
    Date lastUpdated
    static belongsTo = [person: Person, deathVerification: DeathVerification]
    Date personDeath
    static constraints = {
        personDeath(nullable: false)
        deathVerification(nullable: false)
    }
}
