package ps.police.core.person



/*
*
* Obsolete Class
*
*
* */

class ContactDetails implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Set telephoneNumber
    static belongsTo = [person: Person]

    static constraints = {
    }
}
