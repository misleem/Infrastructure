package ps.police.core.person



/*
*
* Obsolete Class
*
*
*
* */

class FingerPrintImage implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated

    byte[] image

    static belongsTo = [fingerPrintHeaderRecord: FingerPrintHeaderRecord]

    static constraints = {
    }

    static mapping = {

        version false
        id column: 'finger_print_header_record_Id', generator: 'assigned'
    }
}
