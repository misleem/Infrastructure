package ps.police.core.person



/*
*
*
*
* Obsolete Class
*
*
*
*
* */

class FacialImageHeaderRecord implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    String aspectRatio
    Long dimensionalImage
    String imageInformation
    String resolution

    static constraints = {
        aspectRatio(nullable: true, blank: true, size: 1..32)
        dimensionalImage(nullable: true, blank: true, size: 1..10)
        imageInformation(nullable: true, blank: true, size: 1..200)
        resolution(nullable: true, blank: true, size: 1..32)
    }
}
