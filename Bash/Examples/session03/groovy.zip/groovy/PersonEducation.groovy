package ps.police.core.person


import ps.police.core.person.lookup.*
import ps.police.core.organization.Organization;

/**
 * @author lenovo
 * @version 1.0
 * @created 15-Dec-2011 12:39:48 PM
 * @param: This class represents the set of a person education degrees for example Masters, BSc ... with more details
 *
 *  dateAttained: the date when the person was granted the degree [Not Null]
 *  educationCode: the degree code like MS, BS ...  [Not Null]
 *  educationInstitute: the institute from where the person is graduated
 *  major: the study major like Computer Science  [Not Null]
 *  educationInstituteName : the name of the institution which graduated the student (person)
 *  person: the specified person (who is graduated from the institution )  [Not Null]
 *
 *
 *
 *
 *
 */
public class PersonEducation implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Date dateAttained;
    EducationDegree educationCode;
    Organization educationInstitute;
    Major major;
    String educationInstituteName;

    static belongsTo = [person: Person]
    static constraints = {
        educationInstituteName(nullable: true, blank: true, size: 1..64)
        dateAttained(nullable: false)
        educationCode(nullable: false)
        major(nullable: false)
        educationInstitute(nullable: true)
    }
}