package ps.police.core.person

import ps.police.core.person.lookup.RecordType

class PersonRecord implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    String recordTypeEnum

    static hasMany = [recordType : RecordType]
    static belongsTo = [person: Person]


    static constraints = {

        person(nullable: false)



    }
}
