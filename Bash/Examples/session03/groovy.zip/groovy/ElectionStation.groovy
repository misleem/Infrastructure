package ps.police.core.person

import ps.police.core.location.*;

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:11 AM
 * @param : This class represents election stations information.
 * electionStationNumber: the election station number (NOT NULL)
 * electionStationnName: the election station name (NOT NULL)
 * stationCode: the election station code   (NOT NULL)
 * centerCode: the election station center code
 * electionCity: the city where the election station is located (NOT NULL)
 * electionGovernorate: the governorate where the election station is located  (NOT NULL)
 *
 *
 *
 *
 */

public class ElectionStation implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Integer electionStationNumber;
    String electionStationnName;
    String stationCode;
    String centerCode;
    Locality electionCity;
    Governorate electionGovernorate;

    static constraints = {
        electionStationNumber(nullable: false)
        electionStationnName(nullable: false, blank: false, size: 1..100)
        stationCode(nullable: false, blank: false, size: 1..3)
		electionCity(nullable:false)
		electionGovernorate(nullable:false)
    }
}