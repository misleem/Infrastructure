package ps.police.core.person



/*
*
*
* Obsolete Class
*
*
*
* */

class FacialImageHeader implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    String formatIdentifier
    String lengthofRecord
    Long numberofFacialImages
    Long versionNumber

    static constraints = {
        formatIdentifier(nullable: true, blank: true, size: 1..32)
        lengthofRecord(nullable: true, blank: true, size: 1..32)
        numberofFacialImages(nullable: true, blank: true)
        versionNumber(nullable: true, blank: true)
    }
}
