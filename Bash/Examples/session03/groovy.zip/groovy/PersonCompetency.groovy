package ps.police.core.person
import ps.police.core.person.lookup.Competency
class PersonCompetency implements Serializable {

    private static final long serialVersionUID = 1L
    Date dateCreated
    Date lastUpdated
    Person person
    Competency competency
//    static belongsTo = [person: Person, competency: Competency]

    static mapping = {
        id composite: ['person', 'competency']
        version false
    }
}
