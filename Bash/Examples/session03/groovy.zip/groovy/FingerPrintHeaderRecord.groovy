package ps.police.core.person

import ps.police.core.person.lookup.FingerImageQuality

import ps.police.core.person.lookup.FingerLengthType



/*
*
* Obsolete Class
*
*
*
* */

class FingerPrintHeaderRecord implements Serializable {

    private static final long serialVersionUID = 1L

    Long countOfViews
    Long fingerPosition
    Long horizontalLineLength
    String impressionType
    Long rotationAngle
    Long verticalLineLength
    Long viewNumber
    Date dateCreated
    Date lastUpdated

    static belongsTo = [fingerImageQuality: FingerImageQuality, fingerLengthType: FingerLengthType]

    static constraints = {
        countOfViews(nullable: true, blank: true)
        fingerPosition(nullable: true, blank: true)
        horizontalLineLength(nullable: true, blank: true)
        impressionType(nullable: true, blank: true, size: 1..64)
        rotationAngle(nullable: true, blank: true)
        verticalLineLength(nullable: true, blank: true)
        viewNumber(nullable: true, blank: true)
        fingerImageQuality(nullable: true)
        fingerLengthType(nullable: true)
    }
}

