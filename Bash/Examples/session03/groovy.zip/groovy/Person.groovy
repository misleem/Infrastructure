package ps.police.core.person

import ps.police.core.person.lookup.BirthVerification
import ps.police.core.location.Location
import ps.police.core.contactmethod.ContactMethod
import ps.police.core.location.Locality
import ps.police.core.location.Country
import ps.police.core.person.lookup.RecordType

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents the personal info related to a person
 *
 * firstName: the person Arabic first name    [Not Null]
 * secondName: the person Arabic second name
 * thirdName: the person Arabic third name
 * fourthName: the person Arabic fourth name
 * motherName: the person Arabic mother name
 * arabicFullName: the person Arabic full name
 * englishFullName: the person English full name
 * engFirstName: the person English first name
 * engSecondName: the person English second name
 * engThirdName: the person English third name
 * engFourthName: the person English fourth name
 * engMotherName: the person English mother name
 * personNickname: the person nick name
 * initials: the person name initials (the first letter of his first name and the first letter of his family name)
 * alternativeSpellingEnglish: another way to writing the person English full name
 * dateOfBirth: the person date of birth   [Not Null]
 * isEmployee: indicates if the person is a police man or not ( the default value is false )
 * needRevision: is "True" if the personal data needs review
 * legalIdentifiers : the person legal identifiers (the legal documents... ID, Passport...)
 * languageInfos : the set of languages known by the person '
 * nationalities: the set of person nationalities
 * identificationMarks: the person identification marks. ( The set of the marks that identifiy the person like tall, weight, .. )
 * disabilityInfos: the disabilities that the person suffers from
 * relationShips: the relationships of the person like "brothers, sisters, ...
 * securityReport: the set of reports that represent the  security data related to the person, for example, the thoughts of the person.
 * electionInformation: the set of person election information
 * arrestRecord: the person arrest records history
 * countryVisit: the set of countries that the person visited
 * employmentRecord: the person employment history
 * healthRecord: the set of diseases that infected the person
 * personEducation: the set of person educational degrees (Masters, BS...)
 * trainingRecord: the set of the training courses that the person has attended, for example, "ICDL"
 * personAddress: the set of the person addresses (Permanent Address, Work Address...)
 * demographicDescriptor: the person demographical data  like ethnicity, number of children .. [Not Null]
 * birthCity: the city where the person was born [Not Null]
 * birthCountry: the country where the person was born [Not Null]
 *
 *
 *
 *
 *
 *
 *
 *
 */

class Person implements Serializable {

    private static final long serialVersionUID = 1L

    //PersonDeath personDeath
    String firstName
    String secondName
    String thirdName
    String fourthName
    String motherName
    String arabicFullName
    String englishFullName
    String engFirstName
    String engSecondName
    String engThirdName
    String engFourthName
    String engMotherName
    String personNickname
    String initials
    String alternativeSpellingEnglish
    Date dateOfBirth;
    Boolean isTrainer =new Boolean(false)
    Boolean isEmployee=new Boolean(false)
    Boolean needRevision =new Boolean(false)
    String applicationName
    BirthVerification birthVerification

    static belongsTo = [demographicDescriptor:DemographicDescriptor,birthCity: Locality, birthCountry: Country]

    String getArabicFullName() {
        StringBuilder fullname = new StringBuilder()
        fullname.append(firstName)
        if (secondName != null && secondName.size() > 0) {
            fullname.append(' ')
            fullname.append(secondName)
        }
        if (thirdName != null && thirdName.size() > 0) {
            fullname.append(' ')
            fullname.append(thirdName)
        }
        fullname.append(' ')
        fullname.append(fourthName)

        return fullname.toString();
    }

    String getEnglishFullName() {

        StringBuilder fullname = new StringBuilder()
        if (engFirstName != null && engFirstName.size() > 0)
            fullname.append(engFirstName)
        if (engSecondName != null && engSecondName.size() > 0) {
            fullname.append(' ')
            fullname.append(engSecondName)
        }

        if (engThirdName != null && engThirdName.size() > 0) {
            fullname.append(' ')
            fullname.append(engThirdName)
        }

        if (engFourthName != null && engFourthName.size() > 0) {
            fullname.append(' ')
            fullname.append(engFourthName)
        }
        return fullname.toString();
    }

    static hasMany = [
            legalIdentifiers: LegalIdentifier,
            languageInfos: LanguageInfo,
            nationalities: Nationality,
            specimenSignatures: SpecimenSignature,
            fingerPrintInfos: FingerPrintInfo,
            facialImageInfos: FacialImageInfo,
            identificationMarks: IdentificationMark,
            disabilityInfos: DisabilityInfo,
            relationShips: RelationShips,
            securityReport: SecurityReport,
            electionInformation: ElectionInformation,
            arrestRecord: ArrestRecord,
            languageInfo: LanguageInfo,
            countryVisit: CountryVisit,
            employmentRecord: EmploymentRecord,
            healthRecord: HealthRecord,
            personEducation: PersonEducation,
            trainingRecord: TrainingRecord,
            personAddress: PersonAddress,
            personCompetency :PersonCompetency ,
            personRecord : PersonRecord
    ]

    static constraints = {

        applicationName(nullable: true)
        electionInformation(nullable: true)
        arrestRecord(nullable: true)
        languageInfo(nullable: true)
        countryVisit(nullable: true)
        employmentRecord(nullable: true)
        demographicDescriptor(nullable: true)
        firstName(blank: false)
        secondName(nullable: true, blank: true)
        thirdName(nullable: true, blank: false)
        fourthName(nullable: true, blank: false)
        personNickname(nullable: true, blank: true)
        engFirstName(nullable: true, blank: true)
        engSecondName(nullable: true, blank: true)
        engThirdName(nullable: true, blank: true)
        engFourthName(nullable: true, blank: true)
        engMotherName(nullable: true, blank: true)
        initials(nullable: true, blank: true)
        alternativeSpellingEnglish(nullable: true, blank: true)
        dateOfBirth(nullable: false)
        birthCity(nullable: true)
        birthVerification(nullable: true)
        arabicFullName(nullable: true)
        englishFullName(nullable: true)
        birthCountry(nullable: true)
        motherName(nullable:true)
        isEmployee(nullable:true)
        isTrainer(nullable:true)
        applicationName(nullable: true)
		disabilityInfos(nullable:true)
		needRevision(nullable:true)
    }

    static mapping = {

        legalIdentifiers cascade: 'all-delete-orphan'
        languageInfos cascade: 'all-delete-orphan'
        nationalities cascade: 'all-delete-orphan'
        specimenSignatures cascade: 'all-delete-orphan'
        fingerPrintInfos cascade: 'all-delete-orphan'
        facialImageInfos cascade: 'all-delete-orphan'
        identificationMarks cascade: 'all-delete-orphan'
        disabilityInfos cascade: 'all-delete-orphan'
        relationShips cascade: 'all-delete-orphan'
        securityReport cascade: 'all-delete-orphan'
        electionInformation cascade: 'all-delete-orphan'
        arrestRecord cascade: 'all-delete-orphan'
        languageInfo cascade: 'all-delete-orphan'
        countryVisit cascade: 'all-delete-orphan'
        employmentRecord cascade: 'all-delete-orphan'
        healthRecord cascade: 'all-delete-orphan'
        personEducation cascade: 'all-delete-orphan'
        trainingRecord cascade: 'all-delete-orphan'
        personAddress cascade: 'all-delete-orphan'
        personCompetency cascade: 'all-delete-orphan'


        legalIdentifiers lazy: true
        languageInfos lazy: true
        nationalities lazy: true
        specimenSignatures lazy: true
        fingerPrintInfos lazy: true
        facialImageInfos lazy: true
        identificationMarks lazy: true
        disabilityInfos lazy: true
        relationShips lazy: true
        securityReport lazy: true
        electionInformation lazy: true
        arrestRecord lazy: true
        languageInfo lazy: true
        countryVisit lazy: true
        employmentRecord lazy: true
        healthRecord lazy: true
        personEducation lazy: true
        trainingRecord lazy: true
        personAddress lazy: true
        personCompetency lazy: true

    }

    String toString() {
        StringBuilder fullname = new StringBuilder()
        fullname.append(firstName)
        if (secondName != null && secondName.size() > 0) {
            fullname.append(' ')
            fullname.append(secondName)
        }
        if (thirdName != null && thirdName.size() > 0) {
            fullname.append(' ')
            fullname.append(thirdName)
        }
        if (fourthName != null && fourthName.size() > 0) {
            fullname.append(' ')
            fullname.append(fourthName)
        }

        return fullname.toString();
    }

}