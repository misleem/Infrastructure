package ps.police.core.person


/*
*
* Obsolete Class
*
*
*
* */

class PersonUrls implements Serializable {

    private static final long serialVersionUID = 1l

    Date dateCreated
    Date lastUpdated

    String personUrl

    boolean vaildUrl

    static belongsTo = [contactDetails: ContactDetails]

    static constraints = {
        personUrl(nullable: true, blank: true, size: 1..124)
        vaildUrl(nullable: true)
    }
}
