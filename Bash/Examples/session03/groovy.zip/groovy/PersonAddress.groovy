package ps.police.core.person

import ps.police.core.contactmethod.ContactUse
import ps.police.core.location.Location
import ps.police.core.contactmethod.ContactLocation
import org.apache.commons.lang.builder.HashCodeBuilder


/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents a person set of addresses
 *
 * contactLocation: the type of the address, for example, "Primary address, Secondary address ...".  [NOT NULL]
 * validFrom: when the person started occupying the address    [NOT NULL]
 * validTo: when the person left the address
 * whenAvailable: the time when the person is available in a specific address, for example, a person named "x" is in address 'y' from 8:00 am - 01:00 pm from SAT-THU
 * addressLocation: the location of the person address  [NOT NULL]
 * person: the specified person    [NOT NULL]
 * postCode: the person address postal code
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */



class PersonAddress implements Serializable {

    private static final long serialVersionUID = 1L;

    Date dateCreated
    Date lastUpdated
    ContactLocation contactLocation
    Date validFrom
    Date validTo;
    String whenAvailable
    Location addressLocation
    Person person
    String postCode


    static constraints = {
        //person(nullable : false)
        //  addressLocation(nullable : false)
        ///use(nullable : false)
		validTo(nullable :true)
		whenAvailable(nullable:true)
		postCode(nullable: true)
		
    }
    static mapping = {
        version false
        id composite: ['addressLocation', 'person'],
                generator: 'assigned'
    }

    boolean equals(other) {
        if (!(other instanceof PersonAddress )) {
            return false
        }
        other.person== person && other.addressLocation== addressLocation
    }

    int hashCode() {
        def builder = new HashCodeBuilder()
        builder.append person
        builder.append addressLocation
        builder.toHashCode()
    }


}
