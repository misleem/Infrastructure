package ps.police.core.person


/*
*
*
*
* Obsolete Class
*
*
* */

class SpecimenSignature implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Integer aspectRatio
    Integer dimensionofImage
    String resolution
    String storageFormat

    static belongsTo = [person: Person]


    static constraints = {
        aspectRatio(nullable: true, size: 1..10)
        dimensionofImage(nullable: true, size: 1..10)
        resolution(nullable: true, size: 1..30)
        storageFormat(nullable: false, size: 1..30)
    }
}
