package ps.police.core.person

/*
*
*
*
* Obsolete Class
*
*
* */

class SpecimenImage implements Serializable {

    private static final long serialVersionUID = 1L

    byte[] image

    Date dateCreated
    Date lastUpdated

    static belongsTo = [specimenSignature: SpecimenSignature]


    static constraints = {

    }
    static mapping = {

        version false
        id column: 'specimen_Signature_Id', generator: 'assigned'

    }
}
