package ps.police.core.person

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents a person health history (diseases that infected the person)
 * typeOfDisease: the type of disease [Serious, Non-serious] [NOT NULL]
 * diseaseName: the disease name  [NOT NULL]
 * affictionDate: the date when the person is infected [NOT NULL]
 * description: description about the disease
 * c: the specified person [NOT NULL]
 *
 *
 *
 *
 *
 *
 */

import ps.police.core.person.lookup.*;
public class HealthRecord implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated

    TypeOfDisease typeOfDisease;
    String diseaseName;
    Date affictionDate;
    String description;
    static belongsTo = [person: Person]
    static constraints = {
        diseaseName(nullable: false, blank: false, size: 1..64)
        description(nullable: true)
        typeOfDisease(nullable: false)
    }
}