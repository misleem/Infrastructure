package ps.police.core.person



/*
*
* Obsolete Class
*
*
*
* */

class FingerPrintHeader implements Serializable {

    private static final long serialVersionUID = 1L

    String captureDeviceId
    String formatIdentifier
    String imageAcquisitionLevel
    String imageCompressionAlgorithm
    String imageRresolution
    Long numberoffingers
    String pixelDepth
    String recordlength
    String rotationAngleEstimationFlag
    String rotatioUncertaintyAngle
    Long scaleUnits
    String scanResolution
    Long versionNnumber
    String verticalImageresolution
    Long verticalScanResolution
    Date dateCreated
    Date lastUpdated


    static constraints = {

        captureDeviceId(nullable: true, blank: true, size: 1..32)
        formatIdentifier(nullable: true, blank: true, size: 1..32)
        imageAcquisitionLevel(nullable: true, blank: true, size: 1..64)
        imageCompressionAlgorithm(nullable: true, blank: true, size: 1..124)
        imageRresolution(nullable: true, blank: true, size: 1..32)
        numberoffingers(nullable: true, blank: true)
        pixelDepth(nullable: true, blank: true, size: 1..64)
        recordlength(nullable: true, blank: true, size: 1..64)
        rotationAngleEstimationFlag(nullable: true, blank: true, size: 1..64)
        rotatioUncertaintyAngle(nullable: true, blank: true, size: 1..64)
        scaleUnits(nullable: true, blank: true)
        scanResolution(nullable: true, blank: true, size: 1..32)
        versionNnumber(nullable: true, blank: true)
        verticalImageresolution(nullable: true, blank: true, size: 1..32)
        verticalScanResolution(nullable: true, blank: true)
    }
}

