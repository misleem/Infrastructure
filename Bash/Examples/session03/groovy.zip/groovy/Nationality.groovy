package ps.police.core.person

import ps.police.core.person.lookup.AcquisitionMethod
import ps.police.core.location.*

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents the person set of nationalities
 *
 *acquiredDate: when the person is granted the nationality   [NOT NULL]
 * person: the person who is granted the nationality [NOT NULL]
 * acquisitionMethod: how the person is granted the nationality, for example, Migration, By Working, ....
 * granterCountry: the country that granted the person its nationality  [NOT NULL]
 *  previousCountry: the person previous citizenship
 *
 *
 *
 *
 *
 *
 *
 *
 */


class Nationality implements Serializable {

    private static final long serialVersionUID = 1L

    Date acquiredDate
    Date dateCreated
    Date lastUpdated

    static belongsTo = [person: Person,
            acquisitionMethod: AcquisitionMethod,
            granterCountry: Country,
            previousCountry: Country
    ]

    static constraints = {

        acquiredDate(nullable: false)
        previousCountry(nullable: true)


    }
}
