package ps.police.core.person

/**
 * @author lenovo
 * @version 1.0
 * @created 14-Dec-2011 11:41:25 AM
 *
 * @param : this class represents a person employment history
 *
 * occupationType: the occupation type such as "Doctor, Teacher ... " [NOT NULL]
 * fromDate: when the person is employed   [NOT NULL]
 * toDate: when the person left the job
 * organizationName: the name of the organization that employed the person [NOT NULL]
 * jobDescription: the job description  [NOT NULL]
 * person: the specified person   [NOT NULL]
 *
 *
 *
 *
 */

import ps.police.core.person.lookup.OccupationType
import org.apache.commons.lang.time.DateUtils

public class EmploymentRecord implements Serializable {

    private static final long serialVersionUID = 1L
    OccupationType occupationType;
    Date fromDate;
    Date toDate;
    String organizationName;
    // Boolean isCurrent;o
    String jobDescription;
    static belongsTo = [person: Person]

    static constraints = {
        occupationType(nullable: true)
        fromDate(nullable: true)
        organizationName(blank: false)
        jobDescription(blank: false)
        toDate(nullable: true, validator: {val, obj ->
            if (val == null || obj.fromDate == null)// if any of the fromDate or toDate is null , the constraint passes.
                return true
            return val.isAfterOrEqual(obj.fromDate) //  toDate >= fromDate
        })

    }
}


	