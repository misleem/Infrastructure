package ps.police.core.person

import ps.police.core.common.LanguageCodeLookup
import ps.police.core.person.lookup.LevelType
import ps.police.core.person.lookup.UserLanguage

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param : this class represents the languages that a person know with different levels for reading, writing and speaking
 *
 *  lLevel: the language speaking level, the level is like "Excellent, good, weak ... "   [NOT NULL]
 *  rLevel: the language reading level        [NOT NULL]
 *  wLevel: the language writing level  [NOT NULL]
 *  languageCodeLookup: the selected language  [NOT NULL]
 *  person: the person who knows the language  [NOT NULL]
 *
 *
 *
 *
 *
 *
 */


class LanguageInfo implements Serializable {
    private static final long serialVersionUID = 1L
    Date dateCreated
    Date lastUpdated
    static belongsTo = [person: Person, userLanguage: UserLanguage,lLevel:LevelType,rLevel:LevelType,wLevel:LevelType]

}
