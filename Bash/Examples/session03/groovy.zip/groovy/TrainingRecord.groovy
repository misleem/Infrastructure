package ps.police.core.person
/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:10 AM
 *
 * @param
 *
 * This class represents the training courses that a person attended
 * trainingFromDate: when the training course is started
 * trainingName: the training name
 * trainingToDate: the training course end date
 * trainingCountry: the country where the course is held
 * traningLocality: the locality where the course is held
 * note: general notes and information about the training course
 * trainingLocation: general description about the training course location
 * traineeName: the trainee name
 * trainingCategory: the training category "Computer, Weapons ..."
 *  person: the person who attended the training course
 *
 *
 *
 *
 *
 *
 */

import ps.police.core.location.*;
import ps.police.core.person.lookup.TrainingCategory;

public class TrainingRecord implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Date trainingFromDate;
    String trainingName;
    Date trainingToDate;
    Country trainingCountry;
    Locality traningLocality;
    String note;
    String trainingLocation;
    String traineeName;
	TrainingCategory trainingCategory
    //Training training;


    static belongsTo = [person: Person]

    static constraints = {
        trainingFromDate(nullable: false)
        trainingToDate(nullable: false)
        trainingCountry(nullable: false)
        trainingCategory(nullable: false)
        traningLocality(nullable: true)
        trainingLocation(nullable: true, blank: true, size: 1..100)
        trainingName(nullable: false, blank: false, size: 1..100)
        note(nullable: true, blank: true, size: 1..150)
		traineeName(nullable: true)
    }

}