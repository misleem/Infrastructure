package ps.police.core.person

import ps.police.core.person.lookup.RelationshipType


/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:06 AM
 * @param :
 *
 *
 * This class represents persons relationship including blood relationships and other relationships like friendship
 *
 * relatedPerson: the related person
 * relationshipType: the relation type like "Brother"
 * relationshipDate: when the relation is started
 * person: the person who created the relation ( the specified person)
 *
 *
 *
 *
 *
 *
 *
 *
 */



class RelationShips implements Serializable {

    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Person relatedPerson
    RelationshipType relationshipType
    Date relationshipDate
    static belongsTo = [person: Person]
    Boolean isDependent

    static constraints = {
       // relationShip(nullable: true, blank: true, size: 1..200)
        relationshipDate(nullable: true)
		relatedPerson(nullable : false)
		relationshipType(nullable:false)
    }
}
