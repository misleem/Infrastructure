package ps.police.core.person

import ps.police.core.common.LanguageCodeLookup;



/*
*
* Obsolete Class
*
*
*
* */

class PersonName implements Serializable {

    private static final long serialVersionUID = 1L

    String firstName
    String secondName
    String thirdName
    String fourthName
    String personNickname
    String motherName
    String initials
    String alternativeSpellingEnglish


    String toString() {
        return new String(firstName + ' ' + secondName + ' ' + thirdName + ' ' + fourthName)
    }

    static constraints = {
        firstName(nullable: false, blank: true, size: 1..64)
        secondName(nullable: true, blank: true, size: 1..64)
        thirdName(nullable: true, blank: true, size: 1..64)
        fourthName(nullable: false, blank: true, size: 1..64)
        personNickname(nullable: true, blank: true, size: 1..64)
        initials(nullable: true, blank: true, size: 1..10)
        alternativeSpellingEnglish(nullable: true, blank: true, size: 1..128)

    }
}
