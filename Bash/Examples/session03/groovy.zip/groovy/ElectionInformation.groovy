package ps.police.core.person

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:10 AM
 * @param: this class represents a person election information data.
 *  voterRegistrationNumber: the person registration number in the elections. This number changes on each election cycle
 *  voterCode: the person voting code
 *  electionStation: election station data where the person is supposed to elect
 *  person: the person who will participate in the election
 *
 *
 *
 *
 */
public class ElectionInformation implements Serializable {
    private static final long serialVersionUID = 1L

    Date dateCreated
    Date lastUpdated
    Integer voterRegistrationNumber;
    String voterCode;
    ElectionStation electionStation;

    static belongsTo = [person: Person]

    static constraints = {
        voterRegistrationNumber(nullable: false)
        voterCode(nullable: false, blank: false, size: 1..10)
        electionStation(nullable: false)
    }
}