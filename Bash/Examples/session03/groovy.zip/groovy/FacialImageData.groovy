package ps.police.core.person


/*
*
* Obsolete Class
*
*
* */

class FacialImageData implements Serializable {

    private static final long serialVersionUID = 1L
    Date dateCreated
    Date lastUpdated
    byte[] image


    static constraints = {
    }
    static belongsTo = [FacialImageHeaderRecord: FacialImageHeaderRecord]


    static mapping = {

        version false
        id column: 'facial_image_header_record_Id', generator: 'assigned'
    }
}
