package ps.police.core.person

import ps.police.core.person.lookup.*;

/**
 * @author Rushdi
 * @version 1.0
 * @created 14-Dec-2011 11:39:05 AM
 * @param: This class represents a person disabilities history
 *
 * disabilityType: the type of the disability like " Short stature, Deaf/Hard-of-Hearing,Blindness or Low Vision... "
 * accomodationNeeded: determines if the person needs accommodation based on the disability type, level and the percentage
 * disabilityLevel: the disability level like "Moderate,Serious ..."
 * percentage: the disability percentage, should be between 1- 100
 * person: the person who suffers from (a) disability(ies)
 *
 *
 *
 *
 */



class DisabilityInfo implements Serializable {

    static final long serialVersionUID = 1L



    Date dateCreated
    Date lastUpdated
    DisabilityType disabilityType
    Boolean accomodationNeeded;
    DisabilityLevel disabilityLevel
    Integer percentage

    static belongsTo = [person: Person]

    static constraints = {
    }

    static mapping = {
    }
}